package com.tts.MapsApp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MapsAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(MapsAppApplication.class, args);
	}

}
